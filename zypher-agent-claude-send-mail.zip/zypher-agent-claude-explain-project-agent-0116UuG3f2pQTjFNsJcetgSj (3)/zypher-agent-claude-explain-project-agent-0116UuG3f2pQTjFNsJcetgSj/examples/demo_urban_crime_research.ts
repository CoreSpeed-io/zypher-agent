#!/usr/bin/env -S deno run -A

/**
 * Urban Crime Prediction Research Demo
 *
 * Search arXiv for papers on urban crime prediction and generate a report
 * Using DeepSeek API for analysis
 */

import "@std/dotenv/load";
import {
  createZypherContext,
  OpenAIModelProvider,
  ZypherAgent,
} from "@zypher/mod.ts";
import { ArXivSearchTool, SendEmailTool, SemanticScholarSearchTool } from "@zypher/tools/mod.ts";
import { encodeBase64 } from "@std/encoding/base64";
import chalk from "chalk";
import { eachValueFrom } from "rxjs-for-await";

// DeepSeek Configuration
const DEEPSEEK_API_KEY = "sk-50ef015b4dbe4bb893c19e0b70c4cc9a";
const DEEPSEEK_BASE_URL = "https://api.deepseek.com";
const DEEPSEEK_MODEL = "deepseek-chat";

// Email configuration
// 临时测试：使用已验证的邮箱地址
const RECIPIENT_EMAIL = "longsheng.zhu22@student.xjtlu.edu.cn";

/**
 * Extract key paper information from report for email body
 */
function extractKeyPapers(report: string): string {
  const lines = report.split('\n');
  let keyPapers = '';
  let paperCount = 0;
  let inPaperList = false;

  for (let i = 0; i < lines.length && paperCount < 5; i++) {
    const line = lines[i];
    
    // Detect paper list section
    if (line.includes('论文清单') || line.includes('Paper') || line.match(/^##?\s*\d+\./)) {
      inPaperList = true;
      continue;
    }

    // Stop if we hit another major section
    if (inPaperList && (line.startsWith('## ') || line.startsWith('# ')) && 
        !line.includes('论文') && !line.includes('Paper')) {
      break;
    }

    // Extract paper information
    if (inPaperList) {
      if (line.match(/^\*\*?\d+\./)) {
        paperCount++;
        keyPapers += `\n${paperCount}. ${line.replace(/^\*\*?\d+\.\s*/, '').replace(/\*\*/g, '')}\n`;
      } else if (line.includes('**作者**') || line.includes('**Authors**')) {
        keyPapers += `   ${line.replace(/\*\*/g, '').trim()}\n`;
      } else if (line.includes('**发表') || line.includes('**Date**') || line.includes('**Published**')) {
        keyPapers += `   ${line.replace(/\*\*/g, '').trim()}\n`;
      }
    }
  }

  return keyPapers || '请查看附件中的完整报告。';
}

async function main() {
  console.log(chalk.cyan("\n" + "═".repeat(70)));
  console.log(chalk.cyan("║" + " ".repeat(68) + "║"));
  console.log(chalk.cyan("║") + chalk.bold.white("     🏙️  Urban Crime Prediction Research - arXiv Search     ") + chalk.cyan("║"));
  console.log(chalk.cyan("║" + " ".repeat(68) + "║"));
  console.log(chalk.cyan("═".repeat(70)));

  try {
    // Initialize DeepSeek provider
    console.log(chalk.blue("\n🔧 Initializing DeepSeek AI..."));
    const provider = new OpenAIModelProvider({
      apiKey: DEEPSEEK_API_KEY,
      baseUrl: DEEPSEEK_BASE_URL,
    });

    console.log(chalk.green("✓ DeepSeek provider initialized"));
    console.log(chalk.gray(`  Model: ${DEEPSEEK_MODEL}`));
    console.log(chalk.gray(`  Base URL: ${DEEPSEEK_BASE_URL}`));

    // Create context and agent
    const context = await createZypherContext(Deno.cwd());
    const agent = new ZypherAgent(context, provider);

    // Register tools
    agent.mcp.registerTool(ArXivSearchTool);
    agent.mcp.registerTool(SemanticScholarSearchTool);

    // Check if email is configured
    const resendKey = Deno.env.get("RESEND_API_KEY");
    const fromEmail = Deno.env.get("FROM_EMAIL");

    if (resendKey && fromEmail) {
      agent.mcp.registerTool(SendEmailTool);
      console.log(chalk.green("✓ Email tool registered"));
    } else {
      console.log(chalk.yellow("⚠️  Email not configured (will display report only)"));
    }

    console.log(chalk.green("✓ ArXiv search tool registered"));
    console.log(chalk.green("✓ Semantic Scholar search tool registered"));
    console.log();

    // Define research task
    const taskDescription = `
Please search for recent papers on "urban crime prediction" or "crime forecasting".

First, try searching arXiv for up to 10 papers. If arXiv search fails, use Semantic Scholar as an alternative data source.

Search for up to 10 papers, focusing on the most recent ones.

After finding the papers, please:

1. **列出论文清单**（中英文标题）
   - 按发表时间从新到旧排序
   - **重要：每篇论文必须明确标注具体的发布时间（格式：YYYY-MM-DD 或 YYYY年MM月DD日）**
   - 包含作者、具体发表日期、论文链接
   - 在论文清单部分，每篇论文的日期信息要清晰可见

2. **总结研究趋势**（用中文）
   - 当前主流的犯罪预测方法
   - 使用的数据类型和特征
   - 主要的机器学习/深度学习模型
   - 应用场景和城市

3. **重点论文分析**（选择2-3篇最相关的）
   - 创新点
   - 方法论
   - 实验结果
   - 局限性

4. **研究展望**
   - 未来研究方向
   - 技术挑战
   - 应用前景

请生成一份结构清晰、内容详实的研究报告。确保每篇论文的发布时间都明确标注在论文清单中（格式：YYYY年或YYYY-MM-DD）。

注意：报告生成后，系统会自动发送邮件，您无需手动发送。
`.trim();

    console.log(chalk.magenta("📝 Research Task:"));
    console.log(chalk.gray("   Search arXiv for urban crime prediction papers"));
    console.log(chalk.gray("   Generate comprehensive analysis report"));
    console.log(chalk.gray(`   Recipient: ${RECIPIENT_EMAIL}\n`));

    console.log(chalk.yellow("🔍 Starting research...\n"));
    console.log(chalk.gray("─".repeat(70)));
    console.log();

    // Run the task
    const events = agent.runTask(taskDescription, DEEPSEEK_MODEL);

    let fullReport = "";
    let toolsUsed = 0;

    for await (const event of eachValueFrom(events)) {
      switch (event.type) {
        case "text":
          fullReport += event.content;
          process.stdout.write(chalk.white(event.content));
          break;

        case "tool_use":
          toolsUsed++;
          console.log(chalk.yellow(`\n\n🔧 Using tool: ${event.toolName}\n`));
          break;

        case "tool_use_approved":
          console.log(chalk.green(`✓ Tool approved\n`));
          break;

        case "cancelled":
          console.log(chalk.red(`\n\n❌ Task cancelled: ${event.reason}`));
          return;

        default:
          break;
      }
    }

    console.log();
    console.log(chalk.gray("─".repeat(70)));
    console.log();

    // Summary
    console.log(chalk.green("\n✅ Research completed!"));
    console.log(chalk.gray(`   Tools used: ${toolsUsed}`));
    console.log(chalk.gray(`   Report length: ${fullReport.length} characters`));

    // Save report to file
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const filename = `urban_crime_prediction_report_${timestamp}.md`;

    await Deno.writeTextFile(filename, fullReport);
    console.log(chalk.blue(`   💾 Report saved to: ${filename}`));

    // Send email with attachment if configured
    if (resendKey && fromEmail) {
      try {
        console.log(chalk.blue("\n📧 Preparing email with attachment..."));
        
        // Encode report content to base64 for attachment
        const encoder = new TextEncoder();
        const reportBytes = encoder.encode(fullReport);
        const base64Content = encodeBase64(reportBytes);

        // Extract key paper information for email body
        const keyPapers = extractKeyPapers(fullReport);
        const emailBody = `城市犯罪预测研究报告已生成。

主要论文信息：
${keyPapers}

完整详细报告请查看附件。

---
生成时间：${new Date().toLocaleString('zh-CN')}
`;

        // Send email using the tool's execute function directly
        const result = await SendEmailTool.execute({
          to: RECIPIENT_EMAIL,
          subject: `城市犯罪预测研究报告 - ${new Date().toLocaleDateString('zh-CN')}`,
          content: emailBody,
          attachment: {
            filename: filename,
            content: base64Content,
          },
        }, {
          workingDirectory: Deno.cwd(),
        });
        
        if (typeof result === 'string') {
          console.log(chalk.green(`\n   ${result}`));
        } else {
          console.log(chalk.green(`\n   📧 Email sent successfully!`));
        }

        console.log(chalk.green(`\n   ${result}`));
      } catch (error) {
        console.error(chalk.red(`\n   ❌ Failed to send email: ${error.message}`));
        console.log(chalk.yellow(`   📄 Report saved locally: ${filename}`));
      }
    } else {
      console.log(chalk.yellow(`   📄 Report displayed above (email not configured)`));
    }

    console.log(chalk.cyan("\n" + "═".repeat(70)));
    console.log(chalk.green("\n🎉 Task completed successfully!\n"));

  } catch (error) {
    console.error(chalk.red("\n❌ Error:"), error.message);
    if (error.stack) {
      console.error(chalk.gray(error.stack));
    }
    Deno.exit(1);
  }
}

// Handle Ctrl+C
Deno.addSignalListener("SIGINT", () => {
  console.log(chalk.yellow("\n\n👋 Research interrupted by user\n"));
  Deno.exit(0);
});

// Run
if (import.meta.main) {
  main().catch((error) => {
    console.error(chalk.red("Fatal error:"), error);
    Deno.exit(1);
  });
}
